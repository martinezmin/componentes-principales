#'es una lista de los componentes pricncipales
#'
#'@param acp (aplicacion de componentes principales ) contiene los componentes principales que ya calculo previamente.
#'@param no_comps nos dice cuantos componentes tenermos
#' @return Devuelve una lista con los componentes principales y el porciento por componente.
#' @export
cpFinales <- function(acp, no_comps){
  CPf <- acp$CP[,1:no_comps]
  return(CPf)
}
