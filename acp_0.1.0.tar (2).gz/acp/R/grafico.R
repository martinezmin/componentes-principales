#'el grafico de los primeros componentes principales
#'
#'@param cpf (componentes principales finales) contiene los componentes principales que se decidieron previamentes.
#' @return Devuelve una grafica de los dos componentes principales el 1 y 2
#' @export
graficaCP <- function(cpf){
  g <- plot(cpf[,1], cpf[,2], type = "p", col = "blue",
            pch = 19, cex = 3,
            main = "Gráfica de los dos primeros CP",
            xlab = "Primer componente",
            ylab = "Segundo componente")
  return(print(g))
}
