#' apliacion de componentes principales
#'
#' Obtiene una lista de componentes principales (PCA) para hacer analisis de datos con un numero de variables.
#'
#' @param X (dataframe o matriz) que contenga en las columnas el número de variables a analizar.
#' @return Devuelve una lista con los componentes principales y el porcentaje de varianza explicada por componente y el acumulado.
#' @export
acp <- function(X){

  # estandarizar las variables
  Z <- scale(X)

  # Matrix de correlacion
  S <- cor(Z)

  # Descomposición eigen-valor - eigenvector
  EV <- eigen(S)

  # Componentes principales
  CP <- Z %*%  EV$vectors

  # Porcentaje de varianza de cada componente
  varianzaTotal <- sum(EV$values)
  porcVar <- EV$values / varianzaTotal*100
  porcVarAcum <- cumsum(porcVar)

  # Devolvemos los CP y los % de varianza de varianza explicados acumulados
  salida <- list(CP = CP, pvar = porcVar , pvar_acum = porcVarAcum)

  return(salida)

}
